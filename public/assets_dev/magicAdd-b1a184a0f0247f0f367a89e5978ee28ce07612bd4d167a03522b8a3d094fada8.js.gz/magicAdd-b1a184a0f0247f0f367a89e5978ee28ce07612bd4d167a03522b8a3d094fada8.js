(() => {
  // app/javascript/magicAdd.js
  var magicAdd = () => {
    console.log("medium XL");
  };
  var magicAdd_default = magicAdd();
})();

